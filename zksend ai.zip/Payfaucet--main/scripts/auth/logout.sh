curl -v --request POST \
     --url https://trading-api.kalshi.com/trade-api/v2/logout \
     --header 'Authorization: {token}' \
     --header 'content-type: application/json'