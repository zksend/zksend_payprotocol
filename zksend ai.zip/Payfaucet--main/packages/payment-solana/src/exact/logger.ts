import { getLogger } from "@logtape/logtape";

export const logger = getLogger(["payfaucet", "payment-solana-exact"]);
