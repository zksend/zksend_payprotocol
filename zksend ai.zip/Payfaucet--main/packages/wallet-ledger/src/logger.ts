import { getLogger } from "@logtape/logtape";

export const logger = getLogger(["payfaucet", "wallet-ledger"]);
